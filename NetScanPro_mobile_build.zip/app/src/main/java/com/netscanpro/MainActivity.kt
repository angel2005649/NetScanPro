package com.netscanpro

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.net.wifi.WifiManager
import android.text.format.Formatter
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import java.net.InetAddress
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val pool = Executors.newSingleThreadExecutor()
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private lateinit var scanButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 32, 28, 24)
            setBackgroundColor(Color.rgb(5, 9, 18))
        }
        val title = TextView(this).apply {
            text = "NetScan Pro"
            textSize = 30f
            setTextColor(Color.rgb(0, 190, 255))
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Analizador de tu red Wi-Fi"
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Listo para analizar tu red"
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(0, 24, 0, 16)
        }
        scanButton = Button(this).apply {
            text = "⟳  Escanear dispositivos"
            setOnClickListener { scan() }
        }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(list) }
        root.addView(title)
        root.addView(subtitle)
        root.addView(status)
        root.addView(scanButton)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        scan()
    }

    private fun scan() {
        scanButton.isEnabled = false
        status.text = "Escaneando la red local…"
        list.removeAllViews()
        pool.execute {
            try {
                val wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                @Suppress("DEPRECATION")
                val ipInt = wifi.connectionInfo.ipAddress
                val ip = Formatter.formatIpAddress(ipInt)
                val parts = ip.split(".")
                if (parts.size != 4 || ip == "0.0.0.0") {
                    runOnUiThread { status.text = "Conéctate a tu Wi-Fi para escanear."; scanButton.isEnabled = true }
                    return@execute
                }
                val prefix = parts.take(3).joinToString(".")
                val found = mutableListOf<String>()
                for (i in 1..254) {
                    val candidate = "$prefix.$i"
                    try {
                        if (InetAddress.getByName(candidate).isReachable(180)) found.add(candidate)
                    } catch (_: Exception) {}
                }
                // Neighbor/ARP table can reveal MAC addresses of devices contacted by the phone.
                val arp = try { java.io.File("/proc/net/arp").readLines().drop(1) } catch (_: Exception) { emptyList() }
                val macByIp = mutableMapOf<String, String>()
                arp.forEach { line ->
                    val cols = line.trim().split(Regex("\\s+"))
                    if (cols.size >= 4 && cols[3].matches(Regex("(?i)([0-9a-f]{2}:){5}[0-9a-f]{2}"))) {
                        macByIp[cols[0]] = cols[3].uppercase()
                    }
                }
                runOnUiThread {
                    status.text = "Red: $ip  •  ${found.size} dispositivos que respondieron"
                    if (found.isEmpty()) addDevice("No se detectaron equipos", "Puede que el router bloquee el escaneo.")
                    found.forEach { address ->
                        val mac = macByIp[address] ?: "MAC no visible"
                        val vendor = vendorName(mac)
                        addDevice(vendor, "IP: $address   •   MAC: $mac")
                    }
                    scanButton.isEnabled = true
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "No se pudo escanear: ${e.message}"; scanButton.isEnabled = true }
            }
        }
    }

    private fun vendorName(mac: String): String {
        if (mac == "MAC no visible") return "Dispositivo detectado"
        val prefix = mac.take(8)
        return when (prefix) {
            "AC:1F:6B", "D8:BB:C1", "3C:5A:B4" -> "Samsung (posible)"
            "7C:1D:D9", "F0:B4:29", " Xiaomi" -> "Xiaomi (posible)"
            "A4:83:E7", "8C:85:90" -> "Motorola / Lenovo (posible)"
            "F8:FF:C2", "00:1B:63" -> "Apple (posible)"
            "B4:CE:F6", "3C:CD:5D" -> "Huawei (posible)"
            else -> "Equipo • fabricante no identificado"
        }
    }

    private fun addDevice(name: String, detail: String) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 16, 18, 16)
            setBackgroundColor(Color.rgb(15, 24, 40))
        }
        val heading = TextView(this).apply {
            text = "●  $name"
            textSize = 18f
            setTextColor(Color.rgb(0, 210, 255))
        }
        val info = TextView(this).apply {
            text = detail
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(0, 8, 0, 0)
        }
        card.addView(heading); card.addView(info)
        val params = LinearLayout.LayoutParams(-1, -2)
        params.setMargins(0, 10, 0, 0)
        list.addView(card, params)
    }
}
